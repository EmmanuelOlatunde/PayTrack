from django.contrib import admin

# Register your models here.
from. models import Member, Payment

admin.site.register(Member)
admin.site.register(Payment)

